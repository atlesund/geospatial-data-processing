

import ast
import json
import os
import random
import webbrowser

import tkinter
import tkinter.filedialog
import tkinter.messagebox
import tkinter.simpledialog

import folium # For mapping
import pyproj # From one system to another




folium_colours = [
    'red', 'blue', 'green', 'purple', 'orange', 
    'darkred', 'lightred', 'beige', 'darkblue', 'darkgreen',
    'cadetblue', 'darkpurple', 'white', 'pink', 'lightblue',
    'lightgreen', 'gray', 'black', 'lightgray'
]

geoformats = {
    'csv': ('CSV Files', '*.csv'),
    'geojson': ('GeoJSON Files', '*.geojson'),
    'shp': ('Shapefiles', '*.shp'),
    'png': ('PNG Files', '*.png')
}



def warning(message, title='Warning'):
    tkinter.Tk().withdraw() # 
    tkinter.messagebox.showwarning(title, message)


def validate(expression):
    """Validate an expression to be processed with eval()"""
    
    validation = {'status': True, 'tokens': []}

    block_list = ['os']

    # Get syntax tree

    try:
        tree = ast.parse(expression, mode='eval')
    except:
        validation['status'] = False
        validation['message'] = f'Syntax error in expression "{expression}"'
        return validation

    # Get relevant tokens

    module = []
    function = []
    arithmetic = []
    logical = []
    relational = []
    constant = []
    label = [] # Field names

    for node in ast.walk(tree):

        class_name = node.__class__.__name__

        if class_name == 'Call':
            try:
                function.append(node.func.id) # simple function
            except:
                module.append(node.func.value.id)
                function.append(f'{node.func.value.id}.{node.func.attr}')
        elif class_name in ['Add', 'Sub', 'Mult', 'Div', 'Pow']:
            arithmetic.append(class_name)
        elif class_name in ['Not', 'And', 'Or']:
            logical.append(class_name)
        elif class_name in ['Eq', 'NotEq', 'Gt', 'Lt', 'GtE', 'LtE']:
            relational.append(class_name)
        elif class_name == 'Constant':
            constant.append(node.value)
        elif hasattr(node, 'id'):
            if node.id not in function and node.id not in module:
                label.append(node.id)

    # Dictionary of tokens

    tokens = {
        'module': module,
        'function': function,
        'arithmetic': arithmetic,
        'logical': logical,
        'relational': relational,
        'constant': constant,
        'label': label
    }

    validation['tokens'] = tokens

    # Check block_list

    for token in tokens['module']:
        if token in block_list:
            validation['status'] = False
            validation['message'] = f'Forbidden keyword "{token}"'
            break

    return validation



def random_points(n, x_min, y_min, x_max, y_max):

    delta_x = x_max - x_min
    delta_y = y_max - y_min

    coordinates = []
    attributes = []

    for count in range(n):
        x_random = x_min + random.random() * delta_x
        y_random = y_min + random.random() * delta_y

        coordinates.append([x_random, y_random])

        attributes.append({
            'fid': count # fid = Feature ID
        })
    return [coordinates, attributes]


def create_osm_point_layer(vector):
    if vector.epsg is None:
        warning('Unknown EPSG code')
        return None
    if vector.epsg == 4326 or vector.epsg == 4258:
        projection = None

    else:
        # TODO: Create projection
        pass

    # Folium Marker color
    if 'colour' in vector.fields:
        colour_field = 'colour'
    elif 'color' in vector.fields:
        colour_field = 'color'
    else:
        colour_field = None
        marker_colour = random.choice(folium_colours)

        

    # Folium marker size
    marker_size = 4

    # Folium layer

    osm_layer = folium.FeatureGroup(name='osm')

    for count, point in enumerate(vector.coordinates):

        # Coordinates

        if projection is None:
            longitude, latitude = point
        else:
            pass # TODO

        # Popup with attributes
        osm_popup_text = ''

        for field, value in vector.attributes[count].items():
            osm_popup_text += field.upper() + ': ' + str(value) + '<br>'

            # Some characters are not allowed in HTML
            # TODO

        osm_popup = folium.Popup(osm_popup_text, max_width=500)

        # Folium colour
        if colour_field is not None:
            marker_colour = vector.attributes[count][colour_field]

        

        # Folium marker


        osm_marker = folium.CircleMarker(
            location = [latitude, longitude], # order is important
            popup = osm_popup,
            radius   = marker_size, 
            color    = marker_colour,
            fill     = True,
            fill_color = marker_colour,
            fill_opacity = 0.4,
        )

        osm_layer.add_child(osm_marker)

    return osm_layer


def show_osm_map(layers, filename='osm.html'):
    """Show layers on OSM base map"""

    osm_map = folium.Map()
    for layer in layers:
        osm_map.add_child(layer)

    osm_map.save(filename)

    webbrowser.open(
        os.path.abspath(filename)
    )